﻿1. Paste the Test procedure of required section in any blank Text file first and save the text file.
2. Please ensure every TP step is on the Next line in the Text file such that no two different steps can be on one line.
3. Once tool is loaded, it will ask for a pop up to select the text file. Please select the Text file where the procedure is present.
4. Tool will then Go through all the Steps in the text file and will capture the steps with verify statement. 
5. Every step must start with step number which is numeric. e.g. (1. Verify XXX )
3. User will be asked to enter the section heading afterwards which will be reflected in acceptance criteria table's first row. 
and also in generated doc file name along with time stamp.
4. Tool will open the result document generated with acceptance criteria once execution is complete. and file will be saved in the folder where the tool is placed.

Note: the Table format is Generated according to the C Series BITE TP-12 Format.

 


