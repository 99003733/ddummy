print ('Loading the Tool. Please wait for some moment...')
print("Developed by : Nandkishor Shirsat, Tejas Arvind")
from docx import Document
import sys, traceback
import time
import datetime
from docx.shared import Cm, Inches
import os, glob
from tkinter import Tk
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt
from tkinter import messagebox
from tkinter.filedialog import askopenfilename
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
import warnings

warnings.simplefilter("ignore", UserWarning)
root = Tk()
root.wm_withdraw()

messagebox.showinfo("ask open filename","Please select the.txt file with Test Procedure\n")
file = askopenfilename(filetypes=[("TP files", "*.txt")])
filename =  file.split("/")[-1].split('.')[0]

Line_String = ""
LineType = 0

file_name = open(file, encoding="UTF-8")
Lines = file_name.readlines()

doc = Document()

table_row = 2
section_heading = input('Enter the Section Heading:\n').strip()

table = doc.add_table(rows=3, cols=5)
table.style = 'Table Grid'
table.autofit = False

table.rows[0].height = Inches(0.25)
table.rows[1].height = Inches(0.50)
table.rows[2].height = Inches(0.25)

#Designing first row of the Table Header
a1 = table.rows[0].cells[0]
b1 = table.rows[0].cells[1]
c1 = table.rows[0].cells[2]
d1 = table.rows[0].cells[3]
e1 = table.rows[0].cells[4]

f1 = d1.merge(e1)
g1 = f1.merge(c1)
h1 = g1.merge(b1)
j1 = h1.merge(a1)
#j1.width = Cm(11)
j1.text = "Test Title: " + section_heading
run1 = j1.paragraphs[0].runs[0]
run1.font.name = 'Times New Roman'
run1.bold = True
run1.font.size = Pt(12)

paragraph = h1.paragraphs[0]
paragraph_format = paragraph.paragraph_format
paragraph_format.alignment = WD_ALIGN_PARAGRAPH.LEFT

#Designing Second row of the Table Header
b = table.rows[1].cells[0]
d = table.rows[1].cells[1]
c = b.merge(d)
#c.width = Cm(5)
c.text = "Test Engineer:"
run = c.paragraphs[0].runs[0]
run.font.name = 'Times New Roman'
run.bold = True
run.font.size = Pt(12)

paragraph = c.paragraphs[0]
paragraph_format = paragraph.paragraph_format
paragraph_format.alignment = WD_ALIGN_PARAGRAPH.LEFT
    
b = table.rows[1].cells[2]
#b.width = Cm(2)
b.text = "Quality Approval:"
run1 = b.paragraphs[0].runs[0]
run1.font.name = 'Times New Roman'
run1.bold = True
run1.font.size = Pt(12)

c = table.rows[1].cells[3]
#c.width = Cm(2)
c.text = "Date:"
run1 = c.paragraphs[0].runs[0]
run1.font.name = 'Times New Roman'
run1.bold = True
run1.font.size = Pt(12)

d = table.rows[1].cells[4]
#d.width = Cm(2)
TextCCR = "Configuration\nControl\nRecord #" 
d.text = TextCCR
run = d.paragraphs[0].runs[0]
run.font.name = 'Times New Roman'
run.bold = True
run.font.size = Pt(12)

#Designing Second row of the Table Header

a = table.rows[2].cells[0]
#a.width = Cm(1)
a.text = "Step#"
run = a.paragraphs[0].runs[0]
run.font.name = 'Times New Roman'
run.bold = True
run.font.size = Pt(12)

paragraph = a.paragraphs[0]
paragraph_format = paragraph.paragraph_format
paragraph_format.alignment = WD_ALIGN_PARAGRAPH.LEFT

b = table.rows[2].cells[1]
#b.width = Cm(5)
b.text = "Procedure Step"
run1 = b.paragraphs[0].runs[0]
run1.font.name = 'Times New Roman'
run1.bold = True
run1.font.size = Pt(12)

c = table.rows[2].cells[2]
#c.width = Cm(2)
c.text = "Perception File:"
run1 = c.paragraphs[0].runs[0]
run1.font.name = 'Times New Roman'
run1.bold = True
run1.font.size = Pt(12)

d = table.rows[2].cells[3]
#d.width = Cm(2)
d.text = "Pass/Fail"
run1 = d.paragraphs[0].runs[0]
run1.font.name = 'Times New Roman'
run1.bold = True
run1.font.size = Pt(12)

e = table.rows[2].cells[4]
#e.width = Cm(2)
e.text = "CR #"
run1 = e.paragraphs[0].runs[0]
run1.font.name = 'Times New Roman'
run1.bold = True
run1.font.size = Pt(12)
   
def Write_To_Word_Document1():
    global Line_String
    global LineType
    global table_row
    global FinalLineType
    global TP_Input 
    if "apply fault" in Line_String.lower() or "clear fault" in Line_String.lower() or "system configuration setup for fault" in Line_String.lower():
        #print (Line_String)
        table_row = table_row + 1
        row = table.add_row()
        ROW = table.rows[table_row].cells[0]
        Temp = table.rows[table_row].cells[4]
        ROW1 = ROW.merge(Temp)
        ROW1.text = Line_String
        run = ROW1.paragraphs[0].runs[0]
        run.font.name = 'Times New Roman'
        run.bold = True
        run.font.size = Pt(12)        
    else:
        #print(Line_String)
        step_no = Line_String.split('. ')[0].strip()
        step_text = Line_String.split('. ', 1)[1].strip()
        table_row = table_row + 1
        row = table.add_row()
        ROW1 = table.rows[table_row].cells[0]
        ROW1.text = step_no
        run = ROW1.paragraphs[0].runs[0]
        run.font.name = 'Times New Roman'
        run.bold = False
        run.font.size = Pt(12)

        paragraph = ROW1.paragraphs[0]
        paragraph_format = paragraph.paragraph_format
        paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER

        ROW3 = table.rows[table_row].cells[1]
        #print(step_text)
        ROW3.text = step_text
        run = ROW3.paragraphs[0].runs[0]
        run.font.name = 'Times New Roman'
        run.bold = False
        run.font.size = Pt(12)

        paragraph = ROW3.paragraphs[0]
        paragraph_format = paragraph.paragraph_format
        paragraph_format.alignment = WD_ALIGN_PARAGRAPH.LEFT
        
def Write_To_Document():
    global Line_String
    global LineType
    if (Line_String == ""):
        pass
    else:
        Write_To_Word_Document1()
        Line_String = ""
        LineType = 0


def String_Update(line, LineType):
    global Line_String
    if (LineType == 1):
        Line_String = line
    if (LineType == 2):
        Line_String = line
    if (LineType == 3) and Line_String != "":
        Line_String = Line_String + "\n" + line
        #print (Line_String)


for line in Lines:
    line = line.strip()
    if len(line.strip()) == 0:
        continue
    elif "Test Procedure" in line or "CAUTION:" in line:
        continue
    else:
        line = line.strip()
        line = line.replace('.	', '. ')
        line = line.replace(':	', ': ')
        if "apply fault" in line.lower() or "clear fault" in line.lower() or "system configuration setup for fault" in line.lower():
            #print ("Head: " + line)
            Write_To_Document()
            LineType = 1
            String_Update(line, LineType)
        elif ". " in line and (line.split('. ')[0].strip().isnumeric()) == True:
            if "verify" in line.split('. ')[1].strip().split(' ')[0].lower():
                #print ("LINE: " + line)
                if LineType != 3:
                    FinalLineType = LineType
                Write_To_Document()
                LineType = 2
                String_Update(line, LineType)
            elif "verify" in line.lower() and ("fault status report" in line.lower() or "RAM" in line) and ("fault code" in line.lower()):
                #print ("LINE: " + line)
                if LineType != 3:
                    FinalLineType = LineType
                Write_To_Document()
                LineType = 2
                String_Update(line, LineType)
            elif "verify" in line.lower() and ("fault history record" in line.lower() or "NVM" in line) and ("fault code" in line.lower() or "following items are present" in line.lower()):
                #print ("LINE: " + line)
                if LineType != 3:
                    FinalLineType = LineType
                Write_To_Document()
                LineType = 2
                String_Update(line, LineType)
            elif "verify" in line.lower() and ("bite" in line.lower() or "EPGS BITE COMMS" in line) and ("annunciated" in line.lower()):
                #print ("LINE: " + line)
                if LineType != 3:
                    FinalLineType = LineType
                Write_To_Document()
                LineType = 2
                String_Update(line, LineType)
            elif "verify" in line.lower() and ("eicas" in line.lower() or "EPGS EICAS" in line) and ("annunciated" in line.lower()):
                #print ("LINE: " + line)
                if LineType != 3:
                    FinalLineType = LineType
                Write_To_Document()
                LineType = 2
                String_Update(line, LineType)  
            else:
                Write_To_Document()
        else:
            #print ("Cont: " + line)
            LineType = 3
            String_Update(line, LineType)
Write_To_Document()

ts = time.time()
st = datetime.datetime.fromtimestamp(ts).strftime('%Y_%m_%d_%H_%M_%S')

for cell in table.columns[0].cells:
    cell.width = Cm(1.72)

for cell in table.columns[1].cells:
    cell.width = Cm(8.05)

for cell in table.columns[2].cells:
    cell.width = Cm(2.48)

for cell in table.columns[3].cells:
    cell.width = Cm(2.27)

for cell in table.columns[4].cells:
    cell.width = Cm(3)
    
new_fil_name =  section_heading + "_" + st + ".docx"
doc.save(new_fil_name)

#messagebox.showinfo("Operation completed", "File has been created with Data Sheet.\n\
#Please click ok to open the file.")
#os.startfile(new_fil_name)
#TP_Input = input("Enter 1 for : BITE TP\nEnter 2 for : Power Transfer TP\nSelect TP:\n").strip()
#messagebox.showinfo("Operation completed", "File has been created with Data Sheet.\n")
#open_option = input("if you want open the file Enter 'Y' or Enter any key to Exit':\n").strip()

#if open_option.lower().strip() == 'y':
    #messagebox.showinfo("Operation completed","Please click ok to open the file\n")
os.startfile(new_fil_name)
print ('Operation Complete')
#else:sys.exit(3)
#print("wrong input")
